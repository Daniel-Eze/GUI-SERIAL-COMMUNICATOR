﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private Bluetooth_Settings _setting = new Bluetooth_Settings();
        public Form1()
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void cOMPortToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _setting.Show();
            _setting._serial.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
        }

        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            SerialPort sp = (SerialPort)sender;
            if (sp.BytesToRead > 0)
            {
                byte[] buffer = new byte[sp.BytesToRead];
                int count = sp.Read(buffer, 0, sp.BytesToRead);
                Extract_each_Character(buffer, count);
            }
        }

        private void Extract_each_Character(byte[] buffer, int count)
        {
            byte data;
            for(int i = 0; i < count; i++)
            {
                data = buffer[i];
                this.Invoke(new EventHandler(update_richtextbox1), new object[] { data });
            }
        }

        private void update_richtextbox1(object sender, EventArgs e)
        {
            byte data = (byte)sender;
            char s = Convert.ToChar(data);
            richTextBox1.TextChanged -= new EventHandler(richTextBox1_TextChanged);//removing text changed event
            richTextBox1.AppendText(s.ToString());
            richTextBox1.TextChanged += new EventHandler(richTextBox1_TextChanged);//adding text changed event
            //richTextBox1.Text += s.ToString();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            int text_length = 0;
            text_length = richTextBox1.TextLength;
            char send_ch = richTextBox1.Text[text_length - 1]; //extracting the last character
            char[] ch = new char[1];
            ch[0] = send_ch;
            if (send_ch == '\n')
            {
                _setting._serial.Write("\r"); // sending carriage return
            }
            else
                _setting._serial.Write(ch,0,1); // sending the character to microcontroller
        }
    }
}
