﻿namespace WindowsFormsApp1
{
    partial class Bluetooth_Settings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.connect_button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.com_port = new System.Windows.Forms.ComboBox();
            this.baud_rate = new System.Windows.Forms.ComboBox();
            this.data = new System.Windows.Forms.ComboBox();
            this.parity = new System.Windows.Forms.ComboBox();
            this.stop_bits = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // connect_button
            // 
            this.connect_button.Location = new System.Drawing.Point(305, 265);
            this.connect_button.Name = "connect_button";
            this.connect_button.Size = new System.Drawing.Size(121, 23);
            this.connect_button.TabIndex = 10;
            this.connect_button.Text = "Connect";
            this.connect_button.UseVisualStyleBackColor = true;
            this.connect_button.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(214, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 16);
            this.label1.TabIndex = 11;
            this.label1.Text = "COM PORT";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(214, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 16);
            this.label2.TabIndex = 12;
            this.label2.Text = "Baud Rate";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(214, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 16);
            this.label3.TabIndex = 13;
            this.label3.Text = "Data";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(214, 193);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 16);
            this.label4.TabIndex = 14;
            this.label4.Text = "Parity";
            // 
            // com_port
            // 
            this.com_port.FormattingEnabled = true;
            this.com_port.Location = new System.Drawing.Point(305, 64);
            this.com_port.Name = "com_port";
            this.com_port.Size = new System.Drawing.Size(121, 24);
            this.com_port.TabIndex = 15;
            // 
            // baud_rate
            // 
            this.baud_rate.FormattingEnabled = true;
            this.baud_rate.Items.AddRange(new object[] {
            "115200",
            "9600"});
            this.baud_rate.Location = new System.Drawing.Point(305, 107);
            this.baud_rate.Name = "baud_rate";
            this.baud_rate.Size = new System.Drawing.Size(121, 24);
            this.baud_rate.TabIndex = 16;
            this.baud_rate.Text = "115200";
            // 
            // data
            // 
            this.data.FormattingEnabled = true;
            this.data.Items.AddRange(new object[] {
            "8 bit",
            "7 bit"});
            this.data.Location = new System.Drawing.Point(305, 147);
            this.data.Name = "data";
            this.data.Size = new System.Drawing.Size(121, 24);
            this.data.TabIndex = 17;
            this.data.Text = "8 bit";
            // 
            // parity
            // 
            this.parity.FormattingEnabled = true;
            this.parity.Items.AddRange(new object[] {
            "none",
            "odd",
            "even",
            "mark",
            "space"});
            this.parity.Location = new System.Drawing.Point(305, 185);
            this.parity.Name = "parity";
            this.parity.Size = new System.Drawing.Size(121, 24);
            this.parity.TabIndex = 18;
            this.parity.Text = "none";
            // 
            // stop_bits
            // 
            this.stop_bits.FormattingEnabled = true;
            this.stop_bits.Items.AddRange(new object[] {
            "1 bit",
            "1.5 bit",
            "2 bit"});
            this.stop_bits.Location = new System.Drawing.Point(305, 222);
            this.stop_bits.Name = "stop_bits";
            this.stop_bits.Size = new System.Drawing.Size(121, 24);
            this.stop_bits.TabIndex = 19;
            this.stop_bits.Text = "1 bit";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(214, 230);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 16);
            this.label5.TabIndex = 20;
            this.label5.Text = "Stop Bits";
            // 
            // Bluetooth_Settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 450);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.stop_bits);
            this.Controls.Add(this.parity);
            this.Controls.Add(this.data);
            this.Controls.Add(this.baud_rate);
            this.Controls.Add(this.com_port);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.connect_button);
            this.Name = "Bluetooth_Settings";
            this.Text = "Bluetooth_Settings";
            this.Load += new System.EventHandler(this.Bluetooth_Settings_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.Button connect_button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox com_port;
        private System.Windows.Forms.ComboBox baud_rate;
        private System.Windows.Forms.ComboBox data;
        private System.Windows.Forms.ComboBox parity;
        private System.Windows.Forms.ComboBox stop_bits;
        private System.Windows.Forms.Label label5;
    }
}